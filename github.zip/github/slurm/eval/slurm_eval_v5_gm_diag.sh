#!/bin/bash
#SBATCH --job-name=gm_diag
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --gres=gpu:1
#SBATCH --time=6:00:00
#SBATCH --output=logs/eval_gm_diag_%j.log
#SBATCH --partition=volta-gpu
#SBATCH --qos=gpu_access

# ── Portable path configuration ──────────────────────────────────────────────
# Set DELPHI_PROJECT_ROOT to the directory containing mimic_pipeline/ and
# Delphi/Delphi-main/ as siblings, e.g.:
#   export DELPHI_PROJECT_ROOT=/your/project/root
PYTHON=${PYTHON:-python}            # override with: export PYTHON=/path/to/envs/delphi/bin/python
DELPHI=${DELPHI_DIR:-${DELPHI_PROJECT_ROOT}/Delphi/Delphi-main}
PIPE=${MIMIC_PIPELINE_DIR:-${DELPHI_PROJECT_ROOT}/mimic_pipeline}
# ─────────────────────────────────────────────────────────────────────────────

PYBIN=${PYTHON}
export PYTHONUNBUFFERED=1

mkdir -p $PIPE/logs \
         $PIPE/eval_output/v5_gm_long \
         $PIPE/eval_output/v5_nogm_long \
         $PIPE/eval_output/v4_gm_long

echo "=== GM Diagnostic: evaluate only patients with seq_len > 128 ==="
echo "Node: $(hostname)  GPU: $CUDA_VISIBLE_DEVICES"
echo "Start: $(date)"
echo ""

cd $DELPHI

# ── Eval A: v5 + GM, long-seq patients only ───────────────────────────────────
echo "=== A: v5 finetune + GM (select=right), seq_len > 128 ==="
echo "Start: $(date)"
$PYBIN evaluate_auc.py \
    --input_path=$PIPE/data/mimic_data_v5 \
    --output_path=$PIPE/eval_output/v5_gm_long \
    --model_ckpt_path=$DELPHI/checkpoints/mimic_v5_finetune/ckpt.pt \
    --labels_file=$PIPE/data/mimic_data_v5/mimic_labels.csv \
    --no_event_token_rate=5 \
    --filter_min_total=20 \
    --min_seq_len=128 \
    --gm_eval
echo "Done A: $(date)"
echo ""

# ── Eval B: v5 no-GM, same long-seq patients (same select='left' baseline) ────
echo "=== B: v5 finetune, no-GM (select=left), seq_len > 128 ==="
echo "Start: $(date)"
$PYBIN evaluate_auc.py \
    --input_path=$PIPE/data/mimic_data_v5 \
    --output_path=$PIPE/eval_output/v5_nogm_long \
    --model_ckpt_path=$DELPHI/checkpoints/mimic_v5_finetune/ckpt.pt \
    --labels_file=$PIPE/data/mimic_data_v5/mimic_labels.csv \
    --no_event_token_rate=5 \
    --filter_min_total=20 \
    --min_seq_len=128
echo "Done B: $(date)"
echo ""

# ── Eval C: v4 + GM, long-seq patients (v4 data) ─────────────────────────────
echo "=== C: v4 stable + GM (select=right), seq_len > 128 ==="
echo "Start: $(date)"
$PYBIN evaluate_auc.py \
    --input_path=$PIPE/data/mimic_data_v4 \
    --output_path=$PIPE/eval_output/v4_gm_long \
    --model_ckpt_path=$DELPHI/checkpoints/mimic_v4_stable/ckpt.pt \
    --labels_file=$PIPE/data/mimic_data_v4/mimic_labels.csv \
    --no_event_token_rate=5 \
    --filter_min_total=20 \
    --min_seq_len=128 \
    --gm_eval
echo "Done C: $(date)"
echo ""

echo "=== All evals complete: $(date) ==="
echo ""

# ── Summary ───────────────────────────────────────────────────────────────────
$PYBIN -c "
import pandas as pd, warnings; warnings.filterwarnings('ignore')

configs = [
    ('v5 + GM  (long-seq)', '$PIPE/eval_output/v5_gm_long'),
    ('v5 no-GM (long-seq)', '$PIPE/eval_output/v5_nogm_long'),
    ('v4 + GM  (long-seq)', '$PIPE/eval_output/v4_gm_long'),
]
for label, path in configs:
    try:
        df = pd.read_parquet(f'{path}/df_both.parquet')
        ch9 = df[df['ICD-10 Chapter (short)'].str.startswith('IX.')]
        neo = df[df['ICD-10 Chapter (short)'].str.startswith('II.')]
        excl = ['Technical', 'Lab Values', 'Death']
        overall = df[~df['ICD-10 Chapter (short)'].isin(excl)]
        print(f'{label}: N={len(df)}  Overall={overall[\"auc\"].mean():.4f}  '
              f'ChIX={ch9[\"auc\"].mean():.4f}  Neoplasm={neo[\"auc\"].mean():.4f}')
    except Exception as e:
        print(f'{label}: ERROR — {e}')
"
